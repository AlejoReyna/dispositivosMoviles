package com.example.eq9_livetranslate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
